"""
AI BoligPotentiale - Komplet app til Replit
============================================
Kør med: python main.py

Indeholder:
- Landing site (HTML/CSS/JS) serveret fra /
- AI-generering API endpoint (/api/generate)
- Stilarter og rumtyper endepunkter

Erstat generate_ai_image() med DIN AI-model kode.
"""

from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
import base64
import os
import uuid
import time
from werkzeug.utils import secure_filename
from shutil import copy2

# ============================================================================
# KONFIGURATION
# ============================================================================

UPLOAD_FOLDER = "static/uploads"
RESULT_FOLDER = "static/results"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

app = Flask(__name__, template_folder="templates", static_folder="static")
CORS(app, origins=["*"])
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

# ============================================================================
# HJÆLPEFUNKTIONER
# ============================================================================

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def image_to_base64(image_path):
    try:
        with open(image_path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    except Exception as e:
        print(f"Fejl ved konvertering til base64: {e}")
        return None


# ============================================================================
# DIN AI-MODEL - SKIFT DETTE UD
# ============================================================================

def generate_ai_image(input_image_path, style, room_type):
    """
    ===================================================================
    INDSÆT DIN AI-MODEL KODE HER
    ===================================================================
    
    Input:  Sti til uploadet billede, stil, rumtype
    Output: Sti til genereret billede
    
    Nedenfor er en PLACEHOLDER der kopierer input.
    Fjern placeholder-koden og indsæt din model.
    """
    
    # ===================================================================
    # PLACEHOLDER - FJERN DETTE OG INDSÆT DIN MODEL
    # ===================================================================
    print(f"  [PLACEHOLDER] Genererer: style={style}, room={room_type}")
    time.sleep(1)  # Simuler AI-processing
    
    output_path = os.path.join(RESULT_FOLDER, f"{uuid.uuid4().hex}.jpg")
    copy2(input_image_path, output_path)  # Kopierer input som placeholder
    # ===================================================================
    
    # ===================================================================
    # EKSEMPEL: Stable Diffusion Img2Img (fjern # for at bruge)
    # ===================================================================
    # from diffusers import StableDiffusionImg2ImgPipeline
    # import torch
    # from PIL import Image
    #
    # pipe = StableDiffusionImg2ImgPipeline.from_pretrained(
    #     "runwayml/stable-diffusion-v1-5",
    #     torch_dtype=torch.float16
    # ).to("cuda")
    #
    # init_image = Image.open(input_image_path).convert("RGB")
    # prompt = f"{style} {room_type} interior design, professional real estate photography, high quality"
    # 
    # result = pipe(
    #     prompt=prompt,
    #     image=init_image,
    #     strength=0.75,
    #     guidance_scale=7.5,
    #     num_inference_steps=50
    # ).images[0]
    # 
    # output_path = os.path.join(RESULT_FOLDER, f"{uuid.uuid4().hex}.jpg")
    # result.save(output_path)
    # return output_path
    # ===================================================================
    
    return output_path


# ============================================================================
# ROUTES - LANDING SITE
# ============================================================================

@app.route("/")
def index():
    """Server landing site"""
    return render_template("index.html")


# ============================================================================
# API ENDPOINTS
# ============================================================================

@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "ok",
        "message": "AI BoligPotentiale API kører",
        "version": "1.0.0"
    })


@app.route("/api/generate", methods=["POST"])
def generate():
    """
    Generer AI-visualisering
    
    Modtager:
        - image: Billede fil (multipart/form-data)
        - style: Stilart
        - room: Rumtype
    
    Returnerer:
        - success: true/false
        - image_base64: Base64 encoded resultat
        - processing_time: Sekunder
    """
    start_time = time.time()
    
    try:
        # 1. Modtag billede
        input_path = None
        
        if "image" in request.files:
            file = request.files["image"]
            if file.filename == "":
                return jsonify({"success": False, "error": "Ingen fil valgt"}), 400
            
            if file and allowed_file(file.filename):
                filename = secure_filename(f"{uuid.uuid4().hex}_{file.filename}")
                input_path = os.path.join(UPLOAD_FOLDER, filename)
                file.save(input_path)
        
        if not input_path:
            return jsonify({
                "success": False,
                "error": "Intet billede modtaget"
            }), 400
        
        # 2. Modtag parametre
        style = request.form.get("style", "modern")
        room_type = request.form.get("room", "livingroom")
        
        valid_styles = ["modern", "scandinavian", "classic", "luxury", "minimal", "nordic", "industrial", "bohemian"]
        valid_rooms = ["kitchen", "livingroom", "bathroom", "bedroom", "office", "dining", "entrance"]
        
        if style not in valid_styles:
            style = "modern"
        if room_type not in valid_rooms:
            room_type = "livingroom"
        
        # 3. Kør AI-generering
        result_path = generate_ai_image(input_path, style, room_type)
        
        if not result_path or not os.path.exists(result_path):
            return jsonify({"success": False, "error": "Generering fejlede"}), 500
        
        # 4. Returner resultat
        result_base64 = image_to_base64(result_path)
        
        if not result_base64:
            return jsonify({"success": False, "error": "Kunne ikke læse resultat"}), 500
        
        processing_time = round(time.time() - start_time, 2)
        
        return jsonify({
            "success": True,
            "image_base64": f"data:image/png;base64,{result_base64}",
            "style": style,
            "room": room_type,
            "processing_time": processing_time
        })
        
    except Exception as e:
        print(f"Fejl: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/styles", methods=["GET"])
def get_styles():
    return jsonify({
        "styles": [
            {"id": "modern", "name": "Moderne"},
            {"id": "scandinavian", "name": "Skandinavisk"},
            {"id": "classic", "name": "Klassisk"},
            {"id": "luxury", "name": "Luksus"},
            {"id": "minimal", "name": "Minimalistisk"},
            {"id": "nordic", "name": "Nordisk"},
            {"id": "industrial", "name": "Industriel"},
            {"id": "bohemian", "name": "Bohemisk"}
        ]
    })


@app.route("/api/rooms", methods=["GET"])
def get_rooms():
    return jsonify({
        "rooms": [
            {"id": "kitchen", "name": "Køkken"},
            {"id": "livingroom", "name": "Stue"},
            {"id": "bathroom", "name": "Badeværelse"},
            {"id": "bedroom", "name": "Soveværelse"},
            {"id": "office", "name": "Kontor"},
            {"id": "dining", "name": "Spisestue"},
            {"id": "entrance", "name": "Entré"}
        ]
    })


# ============================================================================
# START SERVER
# ============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("  AI BoligPotentiale - Komplet App")
    print("=" * 60)
    print("")
    print("  Landing site: http://0.0.0.0:8080/")
    print("  API health:   http://0.0.0.0:8080/api/health")
    print("  API generate: POST http://0.0.0.0:8080/api/generate")
    print("")
    print("  INDSÆT DIN AI-MODEL i generate_ai_image() i main.py")
    print("=" * 60)
    print("")
    
    app.run(host="0.0.0.0", port=8080, debug=True)
