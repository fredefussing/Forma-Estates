/* ============================================
   AI BoligPotentiale - Landing Site JavaScript
   ============================================ */

// ==================== NAVIGATION ====================

window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  if (window.scrollY > 40) {
    nav.classList.add('scrolled');
  } else {
    nav.classList.remove('scrolled');
  }
});

function toggleMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  menu.classList.toggle('open');
}

// ==================== HERO SLIDER ====================

const imagePairs = [
  {
    before: '/static/images/living-scandi-before.jpg',
    after: '/static/images/living-scandi-after.jpg',
    label: 'Stue — Skandinavisk stil'
  },
  {
    before: '/static/images/kitchen-before.jpg',
    after: '/static/images/kitchen-after.jpg',
    label: 'Køkken — Nordisk design'
  },
  {
    before: '/static/images/living-modern-before.jpg',
    after: '/static/images/living-modern-after.jpg',
    label: 'Stue — Modern klassisk'
  }
];

let currentPairIndex = 0;
let sliderPosition = 0;
let isDragging = false;
let phase = 'BEFORE_HOLD';
let timerRef = null;
let swipeFrameRef = null;

const sliderOverlay = document.getElementById('sliderOverlay');
const sliderDivider = document.getElementById('sliderDivider');
const baseImg = document.getElementById('baseImg');
const overlayImg = document.getElementById('overlayImg');
const sliderLabel = document.getElementById('sliderLabel');
const sliderPhase = document.getElementById('sliderPhase');
const heroSlider = document.getElementById('heroSlider');

function updateSlider() {
  sliderOverlay.style.width = sliderPosition + '%';
  overlayImg.style.width = (100 / (sliderPosition / 100 || 0.0001)) + '%';
  sliderDivider.style.left = sliderPosition + '%';
}

function setPhaseText() {
  if (phase === 'BEFORE_HOLD') sliderPhase.textContent = 'Viser før-billede';
  else if (phase === 'SWIPE_TO_AFTER') sliderPhase.textContent = 'AI-visualiserer...';
  else sliderPhase.textContent = 'Viser efter-billede';
}

function loadPair(index) {
  currentPairIndex = index;
  baseImg.src = imagePairs[index].before;
  overlayImg.src = imagePairs[index].after;
  sliderLabel.textContent = imagePairs[index].label;

  // Update dots
  document.querySelectorAll('.slider-dot').forEach((dot, i) => {
    dot.classList.toggle('active', i === index);
  });
}

function runCycle() {
  if (isDragging) return;

  // Phase 1: BEFORE_HOLD - show before for 4 seconds
  sliderPosition = 0;
  phase = 'BEFORE_HOLD';
  setPhaseText();
  updateSlider();

  timerRef = setTimeout(() => {
    if (isDragging) return;

    // Phase 2: SWIPE_TO_AFTER - animate 0% to 100% over 3 seconds
    phase = 'SWIPE_TO_AFTER';
    setPhaseText();

    const swipeDuration = 3000;
    const startTime = performance.now();

    function animateSwipe(now) {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / swipeDuration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      sliderPosition = eased * 100;
      updateSlider();

      if (progress < 1) {
        swipeFrameRef = requestAnimationFrame(animateSwipe);
      } else {
        // Phase 3: AFTER_HOLD - show after for 4 seconds
        sliderPosition = 100;
        phase = 'AFTER_HOLD';
        setPhaseText();
        updateSlider();

        timerRef = setTimeout(() => {
          if (isDragging) return;
          // Next pair
          const nextIndex = (currentPairIndex + 1) % imagePairs.length;
          loadPair(nextIndex);
          runCycle();
        }, 4000);
      }
    }

    swipeFrameRef = requestAnimationFrame(animateSwipe);
  }, 4000);
}

// Dot clicks
document.querySelectorAll('.slider-dot').forEach(dot => {
  dot.addEventListener('click', () => {
    clearTimeout(timerRef);
    cancelAnimationFrame(swipeFrameRef);
    loadPair(parseInt(dot.dataset.index));
    runCycle();
  });
});

// Drag handlers
function handleMove(clientX) {
  const rect = heroSlider.getBoundingClientRect();
  const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
  sliderPosition = Math.max(0, Math.min(100, (x / rect.width) * 100));
  updateSlider();
}

heroSlider.addEventListener('mousedown', () => isDragging = true);
heroSlider.addEventListener('touchstart', (e) => {
  isDragging = true;
  handleMove(e.touches[0].clientX);
}, { passive: true });

window.addEventListener('mousemove', (e) => { if (isDragging) handleMove(e.clientX); });
window.addEventListener('mouseup', () => isDragging = false);
window.addEventListener('touchmove', (e) => { if (isDragging) handleMove(e.touches[0].clientX); }, { passive: true });
window.addEventListener('touchend', () => isDragging = false);

// Start
loadPair(0);
runCycle();

// ==================== SHOWCASE ====================

const showcases = [
  { id: 'showcase0' },
  { id: 'showcase1' },
  { id: 'showcase2' }
];

let activeShowcase = 0;

function showShowcase(index) {
  showcases.forEach((s, i) => {
    const el = document.getElementById(s.id);
    if (i === index) {
      el.style.display = 'block';
      // Reset before/after
      const imgs = el.querySelectorAll('img');
      const labels = el.querySelectorAll('.showcase-label');
      imgs[0].className = 'visible';
      imgs[1].className = 'hidden';
      labels[0].classList.add('active');
      labels[1].classList.remove('active');
      // Reset progress bar
      const bar = el.querySelector('.showcase-progress-bar');
      bar.style.width = '0';
      bar.offsetHeight; // reflow
      bar.style.width = '100%';
    } else {
      el.style.display = 'none';
    }
  });

  // Update thumbs
  document.querySelectorAll('.showcase-thumb').forEach((t, i) => {
    t.classList.toggle('active', i === index);
  });

  activeShowcase = index;
}

// Auto-toggle before/after within each showcase
function toggleShowcaseBeforeAfter() {
  const el = document.getElementById(showcases[activeShowcase].id);
  if (!el || el.style.display === 'none') return;

  const imgs = el.querySelectorAll('img');
  const labels = el.querySelectorAll('.showcase-label');
  const isShowingBefore = imgs[0].className === 'visible';

  if (isShowingBefore) {
    imgs[0].className = 'hidden';
    imgs[1].className = 'visible';
    labels[0].classList.remove('active');
    labels[1].classList.add('active');
  } else {
    imgs[0].className = 'visible';
    imgs[1].className = 'hidden';
    labels[0].classList.add('active');
    labels[1].classList.remove('active');
  }
}

// Auto-switch showcase every 5 seconds
setInterval(() => {
  const next = (activeShowcase + 1) % showcases.length;
  showShowcase(next);
}, 5000);

// Toggle before/after every 4 seconds
setInterval(toggleShowcaseBeforeAfter, 4000);

// Thumbnail clicks
document.querySelectorAll('.showcase-thumb').forEach(thumb => {
  thumb.addEventListener('click', () => {
    showShowcase(parseInt(thumb.dataset.index));
  });
});

// ==================== FAQ ====================

function toggleFaq(button) {
  const item = button.parentElement;
  const isOpen = item.classList.contains('open');

  // Close all
  document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));

  // Open clicked if wasn't open
  if (!isOpen) {
    item.classList.add('open');
  }
}

// ==================== SCROLL ANIMATIONS ====================

const observerOptions = {
  root: null,
  rootMargin: '0px',
  threshold: 0.1
};

const fadeObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, observerOptions);

document.querySelectorAll('.fade-in-up').forEach(el => {
  fadeObserver.observe(el);
});

// ==================== HERO TEXT ANIMATION ====================

window.addEventListener('load', () => {
  const heroEls = document.querySelectorAll('.hero-label, .hero-title, .hero-subtitle, .hero-cta-row, .hero-trust');
  heroEls.forEach((el, i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = `opacity 0.6s ease ${0.2 + i * 0.15}s, transform 0.6s ease ${0.2 + i * 0.15}s`;
    setTimeout(() => {
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    }, 100);
  });
});
